#include <Python.h>
#include "viewfinder.h"

static PyObject* PyGetClosestLevel(PyObject* self, PyObject* args) {
  double meters;

  if (!PyArg_ParseTuple(args, "d", &meters, &meters)) {
    return NULL;
  }

  int result = GetClosestLevel(meters);

  return PyInt_FromLong(result);
}

static PyObject* PyDistanceBetweenLocations(PyObject* self, PyObject* args) {
  double lat1, lng1, lat2, lng2;

  if (!PyArg_ParseTuple(args, "dddd", &lat1, &lng1, &lat2, &lng2)) {
    return NULL;
  }

  double result = DistanceBetweenLocations(lat1, lng1, lat2, lng2);

  return PyFloat_FromDouble(result);
}

static PyObject* PyIndexCells(PyObject* self, PyObject* args) {
  double lat, lng;
  int min_level, max_level;

  if (!PyArg_ParseTuple(args, "ddii", &lat, &lng, &min_level, &max_level)) {
    return NULL;
  }

  std::vector<std::string> cells = IndexCells(lat, lng, min_level, max_level);

  PyObject* list = PyList_New(cells.size());
  for (int i = 0; i < cells.size(); i++) {
    PyList_SET_ITEM(list, i, PyString_FromStringAndSize(cells[i].data(), cells[i].size()));
  }
  return list;
}

static PyObject* PySearchCells(PyObject* self, PyObject* args) {
  double lat, lng, radius;
  int min_level, max_level;

  if (!PyArg_ParseTuple(args, "dddii", &lat, &lng, &radius, &min_level, &max_level)) {
    return NULL;
  }

  std::vector<std::string> cells = SearchCells(lat, lng, radius, min_level, max_level);

  PyObject* list = PyList_New(cells.size());
  for (int i = 0; i < cells.size(); i++) {
    PyList_SET_ITEM(list, i, PyString_FromStringAndSize(cells[i].data(), cells[i].size()));
  }
  return list;
}

static PyMethodDef kS2Methods[] = {
  {"GetClosestLevel", PyGetClosestLevel, METH_VARARGS, ""},
  {"DistanceBetweenLocations", PyDistanceBetweenLocations, METH_VARARGS, ""},
  {"IndexCells", PyIndexCells, METH_VARARGS, ""},
  {"SearchCells", PySearchCells, METH_VARARGS, ""},
  {NULL, NULL, 0, NULL},
};

PyMODINIT_FUNC inits2(void) {
  Py_InitModule("s2", kS2Methods);
}
