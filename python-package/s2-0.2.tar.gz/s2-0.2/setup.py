#!/usr/bin/env python

import os
import sys
from distutils.core import setup, Extension

os_macro = 'OS_MACOSX' if sys.platform == 'darwin' else 'OS_LINUX'

extension = Extension(
    name='s2',
    sources=['base/int128.cc',
             'base/logging.cc',
             'base/stringprintf.cc',
             'base/strtoint.cc',
             'strings/ascii_ctype.cc',
             'strings/stringprintf.cc',
             'strings/strutil.cc',
             'util/coding/coder.cc',
             'util/coding/varint.cc',
             'util/math/mathutil.cc',
             'util/math/mathlimits.cc',
             'util/math/exactfloat/exactfloat.cc',
             's1angle.cc',
             's2.cc',
             's2cellid.cc',
             's2latlng.cc',
             's1interval.cc',
             's2cap.cc',
             's2cell.cc',
             's2cellunion.cc',
             's2edgeindex.cc',
             's2edgeutil.cc',
             's2latlngrect.cc',
             's2loop.cc',
             's2pointregion.cc',
             's2polygon.cc',
             's2polygonbuilder.cc',
             's2polyline.cc',
             's2r2rect.cc',
             's2region.cc',
             's2regioncoverer.cc',
             's2regionintersection.cc',
             's2regionunion.cc',
             's2module.cc',
             'viewfinder.cc'],
    include_dirs=['.'],
    libraries=['crypto'],
    define_macros=[('NDEBUG', '1'),
                   (os_macro, None),
                   ('HASH_NAMESPACE', '__gnu_cxx'),
                   ('S2_USE_EXACTFLOAT', None)])

setup(
    name="s2",
    version='0.2',
    description='Viewfinder wrapper around Google\'s s2 geometry library',
    ext_modules=[extension])
