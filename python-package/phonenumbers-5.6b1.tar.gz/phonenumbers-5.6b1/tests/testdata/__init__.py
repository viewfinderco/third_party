"""Auto-generated file, do not edit by hand."""
# Copyright (C) 2010-2013 The Libphonenumber Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#  http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from phonenumbers.phonemetadata import PhoneMetadata

_AVAILABLE_NONGEO_COUNTRY_CODES = [800, 979]
_AVAILABLE_REGION_CODES = ['AD','AE','AO','AR','AU','BR','BS','BY','DE','GB','IT','JP','KR','MX','NZ','PL','RE','SG','US','YT']

def _load_region(code):
    __import__("region_%s" % code, globals(), locals(),
               fromlist=["PHONE_METADATA_%s" % code], level=1)

for country_code in _AVAILABLE_NONGEO_COUNTRY_CODES:
    PhoneMetadata.register_nongeo_region_loader(country_code, _load_region)

for region_code in _AVAILABLE_REGION_CODES:
    PhoneMetadata.register_region_loader(region_code, _load_region)


# A mapping from a country code to the region codes which
# denote the country/region represented by that country code.
# In the case of multiple countries sharing a calling code,
# such as the NANPA countries, the one indicated with
# "main_country_for_code" in the metadata should be first.
_COUNTRY_CODE_TO_REGION_CODE = {
    1: ("US", "BS",),
    39: ("IT",),
    44: ("GB",),
    48: ("PL",),
    49: ("DE",),
    52: ("MX",),
    54: ("AR",),
    55: ("BR",),
    61: ("AU",),
    64: ("NZ",),
    65: ("SG",),
    81: ("JP",),
    82: ("KR",),
    244: ("AO",),
    262: ("RE", "YT",),
    375: ("BY",),
    376: ("AD",),
    800: ("001",),
    971: ("AE",),
    979: ("001",),
}
