Cog code generation tool.

See http://nedbatchelder.com/code/cog for details.
