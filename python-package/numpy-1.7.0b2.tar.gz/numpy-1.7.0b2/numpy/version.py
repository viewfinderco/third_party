
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.7.0b2'
version = '1.7.0b2'
full_version = '1.7.0b2'
git_revision = '50f71cb65ffc7f31f50fa30fa4354317679c0ede'
release = True

if not release:
    version = full_version
