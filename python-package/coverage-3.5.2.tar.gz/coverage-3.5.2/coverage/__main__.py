"""Coverage.py's main entrypoint."""
import sys
from coverage.cmdline import main
sys.exit(main())
