~~~~
TODO
~~~~

* integrate the 2010 changes/fixes from Nils Johnsson

* add an implementation for the first metaphone algorithm
