from metaphone import doublemetaphone, dm
