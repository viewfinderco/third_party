Producer-consumer example
=========================

.. automodule:: examples.producer_consumer_example

.. literalinclude:: ../../examples/producer_consumer_example.py
    :start-after: # start-file
